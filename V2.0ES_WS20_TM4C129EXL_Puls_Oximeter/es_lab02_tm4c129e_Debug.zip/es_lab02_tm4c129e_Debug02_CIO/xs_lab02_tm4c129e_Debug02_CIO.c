#include <stdio.h>           // for printf

int main(void) {
    printf("Output to console window\n");
    puts("using C I/O functionality");

    printf("some characters... ");
    fflush(stdout);
    puts("more characters");
    while(1){;}
}
