// Include all necessary header files
// #include <file>
//    This variant is used for system header files. It searches for a file named file in a standard list of system directories.
// #include "file"
//    This variant is used for header files of your own program. It searches for a file named file first in the directory containing the current file,
//    then in the quote directories and then the same directories used for <file>.

#include <stdint.h>
#include <stdbool.h>


#include "driverlib/sysctl.h"       // clock

#include "inc/hw_memmap.h"          // for several predefined macros like "GPIO_PORTN_BASE"
#include "driverlib/gpio.h"         // for gpio access





// The error routine that is called if the driver library encounters an error.
#ifdef DEBUG
void
__error__(char *pcFilename, uint32_t ui32Line)
{
}
#endif


//*****************************************************************************
//
// System clock rate in Hz.
//
//*****************************************************************************
uint32_t g_ui32SysClock;      // System clock rate in Hz.





void led_set(unsigned int _id);


int main(void) {
    uint8_t cnt = 0;


    // ------------------------------------------------------------------------
    // MCU
    // ------------------------------------------------------------------------

    // Run from the PLL at 120 MHz.
    g_ui32SysClock = SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ | SYSCTL_OSC_MAIN | SYSCTL_USE_PLL | SYSCTL_CFG_VCO_480), 120000000);



    // ------------------------------------------------------------------------
    //  LEDs on mainboard init
    // ------------------------------------------------------------------------

    //
    // Enable the GPIO port that is used for the on-board LED.
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPION);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);

    //
    // Check if the peripheral access is enabled. (Wait until ready)
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPION)){}
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOF)){}

    //
    // Enable the GPIO pin for the LED (PN0).  Set the direction as output, and
    // enable the GPIO pin for digital function.
    GPIOPinTypeGPIOOutput(GPIO_PORTN_BASE, GPIO_PIN_0|GPIO_PIN_1);
    GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_0|GPIO_PIN_4);

    // switch LEDs off
    GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_0 | GPIO_PIN_1, 0x00);
    GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_0 | GPIO_PIN_4, 0x00);



    // ------------------------------------------------------------------------
    // Main loop
    // ------------------------------------------------------------------------

    // Loop Forever
    while (1) {

        led_set(cnt & 0x03);        // led_set is called with numbers 0,1,2,3

        SysCtlDelay(5000000);

        cnt++;

    }
}


// Set Eval-Board LED number _id
void led_set(unsigned int _id){

    switch(_id){
        case 0:
            // Only LED on Pin G1 on
            GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_0 | GPIO_PIN_4, 0);          // Pin F0 and F4 low
            GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_0 | GPIO_PIN_1, GPIO_PIN_1); // Pin G0 low, G1 high
            break;

        case 1:
            // Only LED on Pin G0 on
            GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_0 | GPIO_PIN_4, 0);          // Pin F0 and F4 low
            GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_0 | GPIO_PIN_1, GPIO_PIN_0); // Pin G1 low, Pin G0 high
            break;

        case 2:
            // Only LED on Pin F4 on
            GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_0 | GPIO_PIN_1, 0);          // Pin G0 and G1 low
            GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_0 | GPIO_PIN_4, GPIO_PIN_4); // Pin F0 low and Pin F4 high
            break;

        case 3:
            // Only LED on Pin F0 on
            GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_0 | GPIO_PIN_1, 0);          // Pin G0 and G1 low
            GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_0 | GPIO_PIN_4, GPIO_PIN_0); // Pin F4 low and Pin F0 high
            break;

    }

    return;
}
