
#include <stdint.h>
#include <stdio.h>
#include <stdbool.h>

#include "driverlib/sysctl.h"       // clock
#include "inc/hw_memmap.h"          // for several predefined macros like "GPIO_PORTN_BASE"
#include "driverlib/gpio.h"         // for gpio access
#include "driverlib/pin_map.h"      //
#include "driverlib/uart.h"         // for uart

#include "utils/uartstdio.h"        // for uartprintf

uint32_t g_ui32SysClock;      // System clock rate in Hz.

int main(void) {
    // Setup MCU => Run from the PLL at 120 MHz.
    g_ui32SysClock = SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ
            | SYSCTL_OSC_MAIN | SYSCTL_USE_PLL | SYSCTL_CFG_VCO_480), 120000000);

    // Setup UART
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);    // Enable the GPIO Peripheral used by the UART.
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);    // Enable UART0
    GPIOPinConfigure(GPIO_PA0_U0RX);                // Configure GPIO Pins for UART mode.
    GPIOPinConfigure(GPIO_PA1_U0TX);                // Configure GPIO Pins for UART mode.
    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);  // Configure GPIO Pins for UART mode.

    UARTStdioConfig(0, 115200, g_ui32SysClock);     // Initialize the UART for console I/O.

    UARTprintf("Output to terminal window\n");      // Output to Terminal

    while(1){;}
}




