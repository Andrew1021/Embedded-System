#include <stdint.h>
#include <stdbool.h>
#include "driverlib/sysctl.h"
#include "CFAF128128B0145T/CFAF128128B0145T.h"

// The error routine that is called if the driver library encounters an error.
#ifdef DEBUG
void
__error__(char *pcFilename, uint32_t ui32Line)
{
}
#endif

int main(void) {
    uint32_t    ui32SysClock;
    uint16_t    color;
    int         i;

    // ------------------------------------------------------------------------
    // MCU
    // ------------------------------------------------------------------------

    // Run from the PLL at 120 MHz.
    ui32SysClock = SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ | SYSCTL_OSC_MAIN | SYSCTL_USE_PLL | SYSCTL_CFG_VCO_480), 120000000);

    // ------------------------------------------------------------------------
    // Display
    // ------------------------------------------------------------------------

    // Parameters:
    // 1. BoosterPack position of the Educational BoosterPack MK II
    // 2. System clock
    // 3. SPI speed
    CFAF128128B0145T_init(2, ui32SysClock, 20000000);


    color = CFAF128128B0145T_color_white;
    i = 0;

    // ------------------------------------------------------------------------
    // Main loop
    // ------------------------------------------------------------------------

    // Loop Forever
    while (1) {

        SysCtlDelay(5000000);

        // Write text to display
        CFAF128128B0145T_text(46, 50, "Welcome", color, CFAF128128B0145T_color_black, 1, 1);

        CFAF128128B0145T_text(61, 60, "to", color, CFAF128128B0145T_color_black, 1, 1);

        CFAF128128B0145T_text(15, 70, "Embedded Systems!", color, CFAF128128B0145T_color_black, 1, 1);

        switch(i++){
            case 0:
                color = CFAF128128B0145T_color_green;
                break;
            case 1:
                color = CFAF128128B0145T_color_red;
                break;
            case 2:
                color = CFAF128128B0145T_color_blue;
                break;
            case 3:
                color = CFAF128128B0145T_color_white;
                i=0;
                break;

        }


    }
}
